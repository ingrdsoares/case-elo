# COMUNICADO: Entrega Final do Projeto — Grupo 18
## BootCamp Nova Geração | EloGroup (2026)

### 📂 Formato de Entrega 1: Código-Fonte & Rastreabilidade
* **Link Oficial do Repositório GitHub:** [https://github.com/ingrdsoares/case-elo](https://github.com/ingrdsoares/case-elo)
* **Equipe / Grupo 18:**
  * **Ingrid Soares** ([@ingrdsoares](https://github.com/ingrdsoares))
  * **Pedro Ribeiro** ([@pedrorpr](https://github.com/pedrorpr))
* **Mentoria Técnica:** Coutinho, EloGroup
* **Data da Banca / Pitch Final:** 23 de Setembro de 2026

---

### 📂 Formato de Entrega 2: Documentação e Materiais Complementares
Todos os arquivos requeridos estão agregados no arquivo compactado:
📦 **`documentacao_e_materiais_complementares_grupo18.zip`**

Formatos aceitos incluídos:
1. **Texto e Documentação:**
   * `.pdf`: `RELATORIO_EXECUTIVO_VERTICE_GRUPO18.pdf` (Relatório executivo final formatado)
   * `.docx`: `RELATORIO_EXECUTIVO_VERTICE_GRUPO18.docx` (Versão Word editável)
   * `.md`: `RELATORIO_EXECUTIVO_VERTICE_GRUPO18.md` e diagnósticos técnicos dos Prompts 1 a 4
2. **Planilhas:**
   * `.xlsx`: `resumo_executivo_vertice_grupo18.xlsx` (Modelagem financeira com 5 abas de KPIs)
3. **Apresentações:**
   * `.pptx`: `apresentacao_pitch_final_vertice_grupo18.pptx` (Deck oficial de 11 slides estruturado para projeção na banca de 23/09)
4. **Gráficos e Evidências Visuais:**
   * Pasta `charts/` com 4 gráficos analíticos em 300 DPI
