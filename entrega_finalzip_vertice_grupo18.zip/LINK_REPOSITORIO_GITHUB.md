# COMUNICADO: Entrega Final do Projeto — Grupo 18
## BootCamp Nova Geração | EloGroup (2026)

### 📂 Formato de Entrega 1: Código-Fonte & Rastreabilidade
* **Link Oficial do Repositório GitHub:** [https://github.com/ingrdsoares/case-elo](https://github.com/ingrdsoares/case-elo)
* **Equipe / Grupo 18:**
  * **Ingrid Soares** ([@ingrdsoares](https://github.com/ingrdsoares)) — Strategy & AI Consultant
  * **Pedro Ribeiro** ([@pedrorpr](https://github.com/pedrorpr)) — Strategy & Analytics Consultant
* **Mentoria Técnica:** Coutinho, EloGroup
* **Data da Banca / Pitch Final:** 23 de Setembro de 2026

---

### 📂 Formato de Entrega 2: Documentação e Materiais Complementares
Todos os documentos e materiais complementares estão agregados no arquivo compactado:
📦 **`entrega_finalzip_vertice_grupo18.zip`** *(e cópia `documentacao_e_materiais_complementares_grupo18.zip`)*

Formatos aceitos incluídos:
1. **Texto e Documentação (.md, .pdf, .docx):**
   * `.pdf`: `RELATORIO_EXECUTIVO_VERTICE_GRUPO18.pdf` (Relatório executivo final formatado)
   * `.docx`: `RELATORIO_EXECUTIVO_VERTICE_GRUPO18.docx` (Versão Word editável)
   * `.md`: `RELATORIO_EXECUTIVO_VERTICE_GRUPO18.md`
   * `.md`: Diagnósticos técnicos completos dos Prompts 1 ao 6:
     * `01_prompt1_data_audit.md` (Data Audit e Auditoria das 5 bases)
     * `02_prompt2_investigacao_hipoteses.md` (Investigação e Árvore de Hipóteses)
     * `03_prompt3_teste_hipoteses_causa_raiz.md` (Teste de Hipóteses e Falseabilidade)
     * `04_prompt4_sintese_executiva.md` (Síntese Executiva do Diagnóstico)
     * `05_prompt5_solucao_prototipo.md` (Arquitetura Técnica de IA e Protótipo)
     * `06_prompt6_business_case_roadmap_pitch.md` (Business Case de R$ 78M, Roadmap 30-60-90, Matriz RACI e Roteiro dos 11 slides)
2. **Planilhas (.xlsx):**
   * `resumo_executivo_vertice_grupo18.xlsx` (Modelagem financeira com 5 abas de KPIs, alavancas e conciliações)
3. **Apresentações (.pptx):**
   * `apresentacao_pitch_final_vertice_grupo18.pptx` e `apres/apresentacao_pitch_vertice_grupo18.pptx` (Deck oficial de 11 slides preparado para projeção na banca de 23/09)
   * `apres/`: Roteiros de fala sincronizados para Pedro Ribeiro e Ingrid Soares (`roteiro_falas_pedro.txt`, `roteiro_falas_ingrid.txt`, `roteiro_integrado_pitch_pedro_e_ingrid.txt`)
4. **Gráficos e Evidências Visuais (.png):**
   * Pasta `charts/` com 4 gráficos forenses em 300 DPI
5. **Prompts e Códigos-Fonte de Apoio:**
   * Pasta `prompts/`: Comandos brutos `prompt1.txt` a `prompt6.txt` e pesquisas técnicas
   * Pasta `scripts/`: Scripts determinísticos em Python (`analise_vertice.py`, `prototipo_ia_vertice5.py`, `business_case_vertice6.py`, `prototipo_solucao_vertice.py`)
